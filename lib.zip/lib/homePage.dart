import 'package:cosmic_app/accountPage.dart';
import 'package:cosmic_app/favoritePage.dart';
import 'package:flutter/material.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  String SolarSystem =
      "The Solar System[c] is the gravitationally bound system of the Sun and the objects that orbit it. It formed 4.6 billion years ago from the gravitational collapse of a giant interstellar molecular cloud. The vast majority (99.86%) of the system's mass is in the Sun, with most of the remaining mass contained in the planet Jupiter. The four inner system planets—Mercury, Venus, Earth and Mars—are terrestrial planets, being composed primarily of rock and metal. The four giant planets of the outer system are substantially larger and more massive than the terrestrials. ";
  String detailplanet =
      "Mars is the fourth planet from the Sun and the second-smallest planet in the Solar System, only being larger than Mercury."
      "In the English language, Mars is named for the Roman god of war.";
  int currentIndexcuy = 0;
  String currentMenu = 'Home';
  String currentDetail = 'Detail Planet';
  String currentTitle = 'Solar System';

  List<Widget> MenuHomePlanet = [
    MenuHome(
        detailplanet:
            "Mars is the fourth planet from the Sun and the second-smallest planet in the Solar System, only being larger than Mercury."
            "In the English language, Mars is named for the Roman god of war.",
        SolarSystem:
            "The Solar System[c] is the gravitationally bound system of the Sun and the objects that orbit it. It formed 4.6 billion years ago from the gravitational collapse of a giant interstellar molecular cloud. The vast majority (99.86%) of the system's mass is in the Sun, with most of the remaining mass contained in the planet Jupiter. The four inner system planets—Mercury, Venus, Earth and Mars—are terrestrial planets, being composed primarily of rock and metal. The four giant planets of the outer system are substantially larger and more massive than the terrestrials. "),
    FavoritePage(),
    AccountPage()
  ];

  void pindahMenu(int Index) {
    setState(() {
      if (Index == 0) {
        currentIndexcuy = Index;
        currentMenu = 'Home';
        currentTitle = 'Solar System';
      } else if (Index == 1) {
        currentIndexcuy = Index;
        currentMenu = 'Favorite';
        currentTitle = 'Favorite';
      } else if (Index == 2) {
        currentIndexcuy = Index;
        currentMenu = 'Account';
        currentTitle = 'Account Info';
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
        debugShowCheckedModeBanner: false,
        home: Scaffold(
          appBar: AppBar(
            leading: Container(
              margin: EdgeInsets.only(left: 5),
              child: CircleAvatar(
                  backgroundColor: Color(0xFF091522),
                  child: ClipOval(
                      child: ElevatedButton(
                    style: ButtonStyle(
                        backgroundColor:
                            MaterialStatePropertyAll(Colors.transparent)),
                    onPressed: () {},
                    child: ImageIcon(
                        AssetImage('assets/gambar/icon_settings.png')),
                  ))),
            ),
            title: Container(
              width: 142,
              height: 50,
              child: Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Container(
                          child: Text(
                        "Yudho Sakti",
                        style:
                            TextStyle(color: Color(0xFF8D8E99), fontSize: 13),
                      ))
                    ],
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Container(
                          child: Text(
                        currentTitle,
                        style:
                            TextStyle(color: Color(0xFFFFFFFF), fontSize: 23),
                      ))
                    ],
                  )
                ],
              ),
            ),
            centerTitle: true,
            actions: [
              Container(
                  width: 60,
                  height: 50,
                  margin: EdgeInsets.only(left: 20),
                  child: ClipOval(
                      child: ElevatedButton(
                    style: ButtonStyle(
                        backgroundColor:
                            MaterialStatePropertyAll(Colors.transparent)),
                    onPressed: () {},
                    child:
                        ImageIcon(AssetImage('assets/gambar/icon_profile.png')),
                  ))),
            ],
            flexibleSpace: Container(
              decoration: BoxDecoration(
                image: DecorationImage(
                  image: AssetImage('assets/gambar/navbar.png'),
                  fit: BoxFit.cover,
                ),
              ),
            ),
            backgroundColor: Color(0xCC091522),
          ),
          body: MenuHomePlanet[currentIndexcuy],
          bottomNavigationBar: BottomNavigationBar(
            backgroundColor: Color.fromRGBO(1, 5, 54, 1),

            //membuat item navigasi
            items: [
              BottomNavigationBarItem(
                icon: Icon(Icons.web_asset),
                label: 'Home',
              ),
              BottomNavigationBarItem(
                  icon: Icon(Icons.favorite), label: 'Favourites'),
              BottomNavigationBarItem(
                  icon: Icon(Icons.more_horiz), label: 'More'),
            ],
            onTap: pindahMenu,
            currentIndex: currentIndexcuy,
            selectedItemColor: Colors.blue,
            unselectedItemColor: Colors.white,
          ),
        ));
  }
}

class MenuHome extends StatelessWidget {
  const MenuHome({
    super.key,
    required this.detailplanet,
    required this.SolarSystem,
  });

  final String detailplanet;
  final String SolarSystem;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      height: double.infinity,
      child: Stack(
        children: [
          Container(
            width: double.infinity,
            height: double.infinity,
            child: Image.asset(
              'assets/gambar/splash.png',
              fit: BoxFit.fill,
            ),
          ),
          SingleChildScrollView(
            scrollDirection: Axis.vertical,
            child: Column(
              children: [
                Divider(),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Container(
                      width: 351,
                      height: 48,
                      child: ListView.builder(
                        itemCount: 4,
                        scrollDirection: Axis.horizontal,
                        itemBuilder: (context, index) {
                          return Container(
                            width: 127,
                            height: 78,
                            margin: EdgeInsets.only(
                              right: 5,
                            ),
                            child: Center(
                                child: Card(
                              borderOnForeground: true,
                              color: Color(0xCC091522),
                              child: Row(
                                children: [
                                  Container(
                                    width: 42,
                                    height: 42,
                                    color: Colors.black12,
                                    child: CircleAvatar(
                                      backgroundColor: Color(0xCC091522),
                                      child: ClipOval(
                                          child: Image.asset(
                                        'assets/gambar/planet.png',
                                      )),
                                    ),
                                  ),
                                  SingleChildScrollView(
                                    scrollDirection: Axis.horizontal,
                                    child: Container(
                                      width: 67,
                                      height: 14,
                                      child: Center(
                                        child: Text(
                                          "Mercury",
                                          style: TextStyle(color: Colors.white),
                                        ),
                                      ),
                                    ),
                                  )
                                ],
                              ),
                            )),
                          );
                        },
                      ),
                    ),
                  ],
                ),
                Divider(),
                Container(
                  width: 327,
                  height: 240,
                  decoration: BoxDecoration(
                      image: DecorationImage(
                          image: AssetImage('assets/gambar/navbar.png'),
                          fit: BoxFit.fill)),
                  child: Column(
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          Container(
                            width: 130,
                            height: 20,
                            margin: EdgeInsets.all(10),
                            child: Center(
                              child: Text(
                                "Planet of the day",
                                style: TextStyle(
                                    fontSize: 16,
                                    fontWeight: FontWeight.w800,
                                    color: Color(0xFFFFFFFF)),
                              ),
                            ),
                          )
                        ],
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          Container(
                            margin: EdgeInsets.only(
                                left: 15, bottom: 60, right: 10),
                            width: 60,
                            height: 60,
                            child: CircleAvatar(
                              backgroundColor: Color(0xCC091522),
                              child: ClipOval(
                                child: Image.asset('assets/gambar/mars.png'),
                              ),
                            ),
                          ),
                          Divider(),
                          Container(
                            width: 210,
                            height: 139,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                    margin: EdgeInsets.all(5),
                                    child: Text(
                                      "Mars",
                                      style: TextStyle(
                                          fontWeight: FontWeight.w800,
                                          fontSize: 16,
                                          color: Color(0xFF11DCE8)),
                                    )),
                                Container(
                                  width: 210,
                                  height: 110,
                                  margin: EdgeInsets.only(left: 5),
                                  child: SingleChildScrollView(
                                      scrollDirection: Axis.vertical,
                                      child: Center(
                                        child: Text(
                                          detailplanet,
                                          style: TextStyle(
                                              color: Color(0xFFFFFFFF)),
                                        ),
                                      )),
                                )
                              ],
                            ),
                          )
                        ],
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: [
                          Container(
                            width: 67,
                            height: 24,
                            margin: EdgeInsets.only(right: 20),
                            child: Row(
                              children: [
                                Text(
                                  "Detail",
                                  style: TextStyle(color: Colors.white),
                                ),
                                Image.asset('assets/gambar/icon_arrow.png')
                              ],
                            ),
                          )
                        ],
                      )
                    ],
                  ),
                ),
                Container(
                  width: 327,
                  height: 252,
                  decoration: BoxDecoration(
                      image: DecorationImage(
                          image: AssetImage('assets/gambar/navbar.png'),
                          fit: BoxFit.fill)),
                  child: Column(
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          Container(
                            width: 100,
                            height: 20,
                            margin: EdgeInsets.all(12),
                            child: Center(
                                child: Text(
                              "Solar System",
                              style: TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.w800,
                                  color: Color(0xFFFFFFFF)),
                            )),
                          ),
                        ],
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Container(
                            width: 300,
                            height: 188,
                            child: SingleChildScrollView(
                                scrollDirection: Axis.vertical,
                                child: Text(
                                  SolarSystem,
                                  style: TextStyle(color: Colors.white),
                                )),
                          )
                        ],
                      )
                    ],
                  ),
                )
              ],
            ),
          )
        ],
      ),
    );
  }
}

class Upper_Navigation_Bar extends StatelessWidget {
  const Upper_Navigation_Bar({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Container(
          width: 375,
          height: 128,
          margin: EdgeInsets.only(top: 35),
          decoration: BoxDecoration(
              image: DecorationImage(
                  image: AssetImage('assets/gambar/navbar.png'),
                  fit: BoxFit.fill)),
          child: Row(
            children: [
              Container(
                width: 60,
                height: 50,
                margin: EdgeInsets.only(left: 20),
                child: CircleAvatar(
                    backgroundColor: Color(0xFF091522),
                    child: ClipOval(
                        child: ElevatedButton(
                      style: ButtonStyle(
                          backgroundColor:
                              MaterialStatePropertyAll(Colors.transparent)),
                      onPressed: () {},
                      child: ImageIcon(
                          AssetImage('assets/gambar/icon_settings.png')),
                    ))),
              ),
              Container(
                width: 142,
                height: 50,
                margin: EdgeInsets.only(left: 40, right: 10),
                child: Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Container(
                            child: Text(
                          "Yudho Sakti",
                          style:
                              TextStyle(color: Color(0xFF8D8E99), fontSize: 13),
                        ))
                      ],
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Container(
                            child: Text(
                          "Solar System",
                          style:
                              TextStyle(color: Color(0xFFFFFFFF), fontSize: 24),
                        ))
                      ],
                    )
                  ],
                ),
              ),
              Container(
                  width: 60,
                  height: 50,
                  margin: EdgeInsets.only(left: 20),
                  child: ClipOval(
                      child: ElevatedButton(
                    style: ButtonStyle(
                        backgroundColor:
                            MaterialStatePropertyAll(Colors.transparent)),
                    onPressed: () {},
                    child:
                        ImageIcon(AssetImage('assets/gambar/icon_profile.png')),
                  ))),
            ],
          ),
        )
      ],
    );
  }
}
