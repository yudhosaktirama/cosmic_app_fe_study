import 'package:cosmic_app/homePage.dart';
// ignore: unused_import
import 'package:cosmic_app/loginPage.dart';
import 'package:flutter/material.dart';
// ignore: unused_import
import 'package:flutter_native_splash/flutter_native_splash.dart';

void main() {
  runApp(MaterialApp(
    debugShowCheckedModeBanner: false,
    home: LoginPage(),
  ));
}

class MyApp extends StatefulWidget {
  const MyApp({super.key});

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  @override
  Widget build(BuildContext context) {
    return HomePage();
  }
}