import 'package:flutter/material.dart';

class AccountPage extends StatefulWidget {
  const AccountPage({super.key});

  @override
  State<AccountPage> createState() => _AccountPageState();
}

class _AccountPageState extends State<AccountPage> {
  bool kitaSwitch = false;
  bool Nilai = false;
  bool Nilai2 = false;
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        appBar: null,
        body: Container(
          decoration: BoxDecoration(
              image: DecorationImage(
                  image: AssetImage('assets/gambar/splash.png'),
                  fit: BoxFit.fill)),
          width: double.infinity,
          height: double.infinity,
          child: SingleChildScrollView(
            child: Column(
              children: [
                Container(
                  width: 380,
                  height: 140,
                  margin: EdgeInsets.only(top: 20),
                  decoration: BoxDecoration(
                      image: DecorationImage(
                          image: AssetImage('assets/gambar/bg_profile.png'))),
                  child: Row(
                    children: [
                      Row(
                        children: [
                          Container(
                            width: 64,
                            height: 64,
                            margin: EdgeInsets.only(left: 40),
                            child: CircleAvatar(
                              backgroundColor: Colors.black,
                              foregroundImage: AssetImage('assets/gambar/yudho.jpg'),
                            ),
                          ),
                          Container(
                            width: 110,
                            height: 64,
                            margin: EdgeInsets.only(left: 10),
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Container(
                                  margin: EdgeInsets.only(bottom: 5),
                                  child: Center(
                                    child: Text(
                                      "Yudho Sakti",
                                      style: TextStyle(
                                          fontWeight: FontWeight.w800,
                                          color: Colors.white,
                                          fontSize: 16),
                                    ),
                                  ),
                                ),
                                Container(
                                  child: Center(
                                    child: Text(
                                      "College Students",
                                      style: TextStyle(color: Colors.white),
                                    ),
                                  ),
                                )
                              ],
                            ),
                          )
                        ],
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: [
                          Container(
                            width: 24,
                            height: 24,
                            margin: EdgeInsets.only(left: 70, bottom: 50),
                            child: CircleAvatar(
                              backgroundColor: Colors.transparent,
                              child: Image.asset(
                                  'assets/gambar/bar_icon_edit.png'),
                            ),
                          )
                        ],
                      ),
                    ],
                  ),
                ),
                Container(
                  width: 380,
                  height: 410,
                  decoration: BoxDecoration(
                      image: DecorationImage(
                          image: AssetImage('assets/gambar/bg_progress.png'),
                          fit: BoxFit.fill)),
                  child: Column(
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          Container(
                            width: 280,
                            height: 30,
                            margin: EdgeInsets.only(top: 30, left: 30),
                            child: Row(
                              children: [
                                Container(
                                  child: Switch(
                                    value: kitaSwitch,
                                    onChanged: (value) {
                                      setState(() {
                                        kitaSwitch = value;
                                        print(kitaSwitch);
                                      });
                                    },
                                    activeTrackColor:
                                        Color.fromRGBO(12, 220, 232, 1),
                                    activeColor: Colors.black,
                                  ),
                                ),
                                Container(
                                  child: Text(
                                    "Show Planetary Progrees",
                                    style: TextStyle(color: Colors.white),
                                  ),
                                )
                              ],
                            ),
                          ),
                        ],
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Container(
                            width: 220,
                            height: 220,
                            margin: EdgeInsets.only(top: 8),
                            decoration: BoxDecoration(
                                image: DecorationImage(
                                    image: AssetImage(
                                        'assets/gambar/progress_circle.png'))),
                          )
                        ],
                      ),
                      Row(
                        children: [
                          Container(
                            width: 200,
                            height: 30,
                            margin: EdgeInsets.only(top: 8, left: 15),
                            child: Row(
                              children: [
                                Checkbox(
                                  value: this.Nilai,
                                  onChanged: (value) {
                                    setState(() {
                                      this.Nilai = value!;
                                    });
                                  },
                                  activeColor: Colors.black,
                                  checkColor: Color.fromRGBO(12, 220, 232, 1),
                                ),
                                Container(
                                  child: Center(
                                    child: Text("Show me Planet Rating",style: TextStyle(
                                      color: Colors.white
                                    ),),
                                  ),
                                )
                              ],
                            ),
                          )
                        ],
                      ),
                      Divider(),
                      Row(
                        children: [
                          Container(
                            width: 200,
                            height: 30,
                            margin: EdgeInsets.only(top: 8, left: 15),
                            child: Row(
                              children: [
                                Checkbox(
                                  value: this.Nilai2,
                                  onChanged: (value) {
                                    setState(() {
                                      this.Nilai2 = value!;
                                    });
                                  },
                                  activeColor: Colors.black,
                                  checkColor: Color.fromRGBO(12, 220, 232, 1),
                                ),
                                Container(
                                  child: Center(
                                    child: Text("Show me Planet Rating",style: TextStyle(
                                      color: Colors.white
                                    ),),
                                  ),
                                )
                              ],
                            ),
                          )
                        ],
                      )
                    ],
                  ),
                )
              ],
            ),
          ),
        ),
      ),
    );
  }
}
