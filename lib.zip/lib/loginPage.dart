import 'package:cosmic_app/homePage.dart';
import 'package:flutter/material.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        resizeToAvoidBottomInset: false,
        appBar: null,
        body: Container(
          width: double.infinity,
          height: double.infinity,
          child: Stack(
            children: [
              Container(
                width: double.infinity,
                height: double.infinity,
                child: Image.asset(
                  'assets/gambar/splash.png',
                  fit: BoxFit.fill,
                ),
              ),
              Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Container(
                        margin: EdgeInsets.only(top: 60, bottom: 30),
                        child: Image.asset('assets/gambar/Vector.png'),
                      )
                    ],
                  ),
                  Divider(),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Column(
                        children: [
                          Stack(
                            children: [
                              Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Container(
                                    width: 375,
                                    height: 475,
                                    decoration: BoxDecoration(
                                        image: DecorationImage(
                                            image: AssetImage(
                                                'assets/gambar/bg_login.png'),
                                            fit: BoxFit.fill)),
                                    child: Column(
                                      children: [
                                        Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.start,
                                          children: [
                                            Container(
                                              margin: EdgeInsets.all(30),
                                              child: Center(
                                                child: Text(
                                                  "Sign in",
                                                  style: TextStyle(
                                                      fontSize: 30,
                                                      color: Color(0xFFFFFFFF),
                                                      fontWeight:
                                                          FontWeight.w800),
                                                ),
                                              ),
                                            )
                                          ],
                                        ),
                                        Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.center,
                                          children: [
                                            Column(
                                              children: [
                                                Container(
                                                  width: 279,
                                                  height: 70,
                                                  child: TextField(
                                                    style: TextStyle(
                                                        color: Colors.white),
                                                    decoration: InputDecoration(
                                                        fillColor: Colors.black,
                                                        filled: true,
                                                        border: OutlineInputBorder(
                                                            borderRadius:
                                                                BorderRadius
                                                                    .circular(
                                                                        44)),
                                                        hintText:
                                                            'Enter Your E-Mail',
                                                        hintStyle: TextStyle(
                                                            color: Color(
                                                                0xFF8D8E99))),
                                                  ),
                                                ),
                                                Container(
                                                  width: 279,
                                                  height: 70,
                                                  child: TextField(
                                                    obscureText: true,
                                                    style: TextStyle(
                                                        color: Colors.white),
                                                    decoration: InputDecoration(
                                                        fillColor: Colors.black,
                                                        filled: true,
                                                        border: OutlineInputBorder(
                                                            borderRadius:
                                                                BorderRadius
                                                                    .circular(
                                                                        44)),
                                                        hintText:
                                                            'Enter Your Password',
                                                        hintStyle: TextStyle(
                                                            color: Color(
                                                                0xFF8D8E99))),
                                                  ),
                                                ),
                                                Container(
                                                  width: 279,
                                                  height: 18,
                                                  margin:
                                                      EdgeInsets.only(left: 5),
                                                  child: Text(
                                                    "Forgot Password ?",
                                                    style: TextStyle(
                                                        color:
                                                            Color(0xFF11DCE8)),
                                                  ),
                                                ),
                                                Divider(),
                                                Builder(
                                                  builder: (context) {
                                                    return Container(
                                                      width: 279,
                                                      height: 44,
                                                      child: FloatingActionButton
                                                          .extended(
                                                              onPressed: () {
                                                                Navigator.push(
                                                                    context,
                                                                    MaterialPageRoute(
                                                                  builder:
                                                                      (context) {
                                                                    return HomePage();
                                                                  },
                                                                ));
                                                              },
                                                              backgroundColor:
                                                                  Color.fromRGBO(0,
                                                                      229, 229, 1),
                                                              label: Text(
                                                                "Sign In",
                                                                style: TextStyle(
                                                                    color: Color(
                                                                        0xFFFFFFFF),
                                                                    fontSize: 24),
                                                              )),
                                                    );
                                                  }
                                                ),
                                                Divider(),
                                                Container(
                                                  width: 100,
                                                  height: 19,
                                                  child: Text(
                                                    "or sign in using",
                                                    style: TextStyle(
                                                        color:
                                                            Color(0xFF8D8E99),
                                                        fontSize: 14),
                                                  ),
                                                ),
                                                Row(
                                                  children: [
                                                    Container(
                                                        width: 68,
                                                        height: 68,
                                                        child:
                                                            FloatingActionButton(
                                                          onPressed: () {},
                                                          backgroundColor:
                                                              Colors
                                                                  .transparent,
                                                          child: ClipOval(
                                                              child: Image.asset(
                                                                  'assets/gambar/twitter.png',
                                                                  width: 100,
                                                                  height: 100,
                                                                  fit: BoxFit
                                                                      .cover)),
                                                        )),
                                                    Container(
                                                        width: 68,
                                                        height: 68,
                                                        child:
                                                            FloatingActionButton(
                                                          onPressed: () {},
                                                          backgroundColor:
                                                              Colors
                                                                  .transparent,
                                                          child: ClipOval(
                                                              child: Image.asset(
                                                                  'assets/gambar/facebook.png',
                                                                  width: 100,
                                                                  height: 100,
                                                                  fit: BoxFit
                                                                      .cover)),
                                                        )),
                                                    Container(
                                                        width: 68,
                                                        height: 68,
                                                        child:
                                                            FloatingActionButton(
                                                          onPressed: () {},
                                                          backgroundColor:
                                                              Colors
                                                                  .transparent,
                                                          child: ClipOval(
                                                              child: Image.asset(
                                                                  'assets/gambar/google.png',
                                                                  width: 100,
                                                                  height: 100,
                                                                  fit: BoxFit
                                                                      .cover)),
                                                        ))
                                                  ],
                                                ),
                                                Row(
                                                  children: [
                                                    Container(
                                                      width: 279,
                                                      height: 17,
                                                      margin: EdgeInsets.only(
                                                          top: 5),
                                                      child: Row(
                                                        mainAxisAlignment:
                                                            MainAxisAlignment
                                                                .center,
                                                        children: [
                                                          Center(
                                                            child: Text(
                                                              "Don't have an account ? ",
                                                              style: TextStyle(
                                                                  fontSize: 12,
                                                                  color: Color(
                                                                      0xFF8D8E99)),
                                                            ),
                                                          ),
                                                          Center(
                                                            child: Text(
                                                              "Sign Up",
                                                              style: TextStyle(
                                                                  fontSize: 12,
                                                                  color: Color
                                                                      .fromRGBO(
                                                                          17,
                                                                          220,
                                                                          232,
                                                                          1)),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    )
                                                  ],
                                                )
                                              ],
                                            )
                                          ],
                                        )
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ],
                      )
                    ],
                  )
                ],
              )
            ],
          ),
        ),
      ),
    );
  }
}
