import 'package:cosmic_app/detail.dart';
import 'package:flutter/material.dart';

class FavoritePage extends StatefulWidget {
  const FavoritePage({super.key});

  @override
  State<FavoritePage> createState() => _FavoritePageState();
}

class _FavoritePageState extends State<FavoritePage> {
  List<databasePlanet> dataPlanet = [
    databasePlanet("Merkurius", "Mercury is the smallest planet in the Solar System and the closest to the Sun."
    , "5.97", "9.8", "24", "5.97", "15", "11.2"),
    databasePlanet("Venus", "Venus is the second planet from the Sun and is Earth's closest planetary neighbor."
    , "5.97", "9.8", "24", "5.97", "15", "11.2"),
    databasePlanet("Bumi", "Earth is an ellipsoid with a circumference of about 40,000 km. It is the densest planet in the Solar System."
    , "5.97", "9.8", "24", "5.97", "15", "11.2"),
     databasePlanet("Mars", "Mars is the fourth planet from the Sun and the second-smallest planet in the Solar System"
    , "5.97", "9.8", "24", "5.97", "15", "11.2"),
     databasePlanet("Jupiter", "Jupiter is the fifth planet from the Sun and the largest in the Solar System. It is a gas giant with a mass more than two and a half times that of all the other planets in the Solar System combined."
    , "1.898", "24.79", "4,380", "778.5", "15", "11.2"),
    databasePlanet("Saturnus", "Saturn is the sixth planet from the Sun and the second-largest in the Solar System, after Jupiter. It is a gas giant with an average radius of about nine and a half times that of Earth."
    , "687", "10.44", "10,585", "1.434", "15", "11.2"),
  databasePlanet("Uranus", "Uranus is the seventh planet from the Sun and is a gaseous cyan ice giant. Most of the planet is made out of water, ammonia, and methane in a supercritical phase of matter, which in astronomy is called 'ice' or volatiles."
    , "5.97", "8.87", "30,660", "2.871", "15", "11.2"),
  databasePlanet("Neptunus", "Neptune is the eighth planet from the Sun and the farthest known planet in the Solar System. It is the fourth-largest planet in the Solar System by diameter, the third-most-massive planet, and the densest giant planet."
    , "5.97", "9.8", "60,225", "4.495", "15", "11.2"),

  ];

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        appBar: null,
        body: Container(
          decoration: BoxDecoration(
              image: DecorationImage(
                  image: AssetImage('assets/gambar/splash.png'),
                  fit: BoxFit.fill)),
          width: double.infinity,
          height: double.infinity,
          child: ListView(
              scrollDirection: Axis.vertical,
              children: dataPlanet.map(
                (dataplanetCuy) {
                  return Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Container(
                        width: 380,
                        height: 180,
                        margin: EdgeInsets.all(5),
                        decoration: BoxDecoration(
                            image: DecorationImage(
                                image: AssetImage(
                                    'assets/gambar/bg_list_planet.png'))),
                        child: Column(
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [
                                Container(
                                  width: 65,
                                  height: 65,
                                  margin: EdgeInsets.only(left: 45, top: 35),
                                  child: CircleAvatar(
                                    radius: 30,
                                    backgroundColor: Colors.transparent,
                                    backgroundImage:
                                        AssetImage('assets/gambar/mars.png'),
                                  ),
                                ),
                                Container(
                                  width: 200,
                                  height: 120,
                                  margin: EdgeInsets.only(top: 40, left: 10),
                                  child: Column(
                                    children: [
                                      Row(
                                        children: [
                                          Container(
                                            width: 70,
                                            height: 24,
                                            margin: EdgeInsets.only(
                                                top: 5, left: 5),
                                            child: Text(
                                              dataplanetCuy.namaPlanet,
                                              style: TextStyle(
                                                  color: Color(0xFF11DCE8),
                                                  fontWeight: FontWeight.w800),
                                            ),
                                          ),
                                          Container(
                                            width: 24,
                                            height: 24,
                                            margin: EdgeInsets.only(
                                                left: 90, top: 5),
                                            child: CircleAvatar(
                                              backgroundColor:
                                                  Colors.transparent,
                                              child: Image.asset(
                                                  'assets/gambar/icon_fav.png'),
                                            ),
                                          )
                                        ],
                                      ),
                                      Row(
                                        children: [
                                          Container(
                                            width: 190,
                                            height: 61,
                                            margin: EdgeInsets.only(
                                                top: 5, left: 5),
                                            child: SingleChildScrollView(
                                              scrollDirection: Axis.vertical,
                                              child: Center(
                                                child: Text(
                                                  dataplanetCuy.detailPlanet,
                                                  style: TextStyle(
                                                      color: Colors.white),
                                                ),
                                              ),
                                            ),
                                          )
                                        ],
                                      ),
                                      Row(
                                        children: [
                                          Builder(
                                            builder: (context) {
                                              return GestureDetector(
                                                onTap: () {
                                                  Navigator.push(context,
                                                      MaterialPageRoute(
                                                    builder: (context) {

                                                      return DetailPage(
                                                        namaPlanet: dataplanetCuy.namaPlanet,
                                                        day: dataplanetCuy.day,
                                                        distance: dataplanetCuy.distance,
                                                        gravity: dataplanetCuy.gravity,
                                                        mass: dataplanetCuy.mass,
                                                        temp: dataplanetCuy.temp,
                                                        velocity: dataplanetCuy.velocity,
                                                      );
                                                    },
                                                  ));
                                                },
                                                child: Container(
                                                  width: 66,
                                                  height: 24,
                                                  margin: EdgeInsets.only(
                                                      left: 134),
                                                  child: Row(
                                                    children: [
                                                      Container(
                                                        child: Text(
                                                          "Detail",
                                                          style: TextStyle(
                                                              color:
                                                                  Colors.white,
                                                              fontWeight:
                                                                  FontWeight
                                                                      .w700),
                                                        ),
                                                      ),
                                                      Container(
                                                        child: Image.asset(
                                                            'assets/gambar/icon_arrow.png'),
                                                      )
                                                    ],
                                                  ),
                                                ),
                                              );
                                            },
                                          )
                                        ],
                                      )
                                    ],
                                  ),
                                )
                              ],
                            )
                          ],
                        ),
                      ),
                    ],
                  );
                },
              ).toList()),
        ),
      ),
    );
  }
}

class databasePlanet {
  final String namaPlanet;
  final String detailPlanet;
  final String mass;
  final String gravity;
  final String day;
  final String velocity;
  final String temp;
  final String distance;

  databasePlanet(this.namaPlanet, this.detailPlanet,this.mass,
    this.gravity,
     this.day,
     this.distance,
    this.temp,
    this.velocity,);
}


